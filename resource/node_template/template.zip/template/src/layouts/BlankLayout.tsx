import React from 'react';

const Layout: React.FC = ({ children }) => <>{children}</>;

export default Layout;
