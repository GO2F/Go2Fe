// extends字段类型定义
import { TypeKey, TypeExtends } from 'config/extend_config';

export { TypeKey, TypeExtends };
