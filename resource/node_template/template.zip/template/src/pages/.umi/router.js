import React from 'react';
import {
  Router as DefaultRouter,
  Route,
  Switch,
  StaticRouter,
} from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@@/history';
import RendererWrapper0 from '/mnt/f/www/basic_framework/go-demo/template/testv3/src/pages/.umi/LocaleWrapper.jsx';
import { routerRedux, dynamic as _dvaDynamic } from 'dva';

const Router = routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__BasicLayout" */ '../../layouts/BasicLayout'),
          LoadingComponent: require('/mnt/f/www/basic_framework/go-demo/template/testv3/src/components/PageLoading/index')
            .default,
        })
      : require('../../layouts/BasicLayout').default,
    routes: [
      {
        path: '/component',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__component___layout" */ '../component/_layout.tsx'),
              LoadingComponent: require('/mnt/f/www/basic_framework/go-demo/template/testv3/src/components/PageLoading/index')
                .default,
            })
          : require('../component/_layout.tsx').default,
        name: '123123',
        routes: [
          {
            path: '/component/list',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__component__list__index" */ '../component/list/index.tsx'),
                  LoadingComponent: require('/mnt/f/www/basic_framework/go-demo/template/testv3/src/components/PageLoading/index')
                    .default,
                })
              : require('../component/list/index.tsx').default,
            extendConfig: {
              keyList: [
                {
                  key: 'id',
                  title: 'id',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: true,
                },
                {
                  key: 'display_name',
                  title: '组件名',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: false,
                },
                {
                  key: 'package_name',
                  title: 'npm包名',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'dev_list_json',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'description',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'site_url',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'remark',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
              ],
              baseApiPath: '/api/component',
              pageConfig: {
                create: true,
                update: true,
                detail: true,
              },
              baseUrlPath: '/component',
            },
            exact: true,
          },
          {
            path: '/component/create',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__component__create__index" */ '../component/create/index.tsx'),
                  LoadingComponent: require('/mnt/f/www/basic_framework/go-demo/template/testv3/src/components/PageLoading/index')
                    .default,
                })
              : require('../component/create/index.tsx').default,
            exact: true,
            extendConfig: {
              keyList: [
                {
                  key: 'id',
                  title: 'id',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: true,
                },
                {
                  key: 'display_name',
                  title: '组件名',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: false,
                },
                {
                  key: 'package_name',
                  title: 'npm包名',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'dev_list_json',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'description',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'site_url',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'remark',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
              ],
              baseApiPath: '/api/component',
              pageConfig: {
                create: true,
                update: true,
                detail: true,
              },
              baseUrlPath: '/component',
            },
          },
          {
            path: '/component/update/:id',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__component__create__index" */ '../component/create/index.tsx'),
                  LoadingComponent: require('/mnt/f/www/basic_framework/go-demo/template/testv3/src/components/PageLoading/index')
                    .default,
                })
              : require('../component/create/index.tsx').default,
            extendConfig: {
              keyList: [
                {
                  key: 'id',
                  title: 'id',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: true,
                },
                {
                  key: 'display_name',
                  title: '组件名',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: false,
                },
                {
                  key: 'package_name',
                  title: 'npm包名',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'dev_list_json',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'description',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'site_url',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'remark',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
              ],
              baseApiPath: '/api/component',
              pageConfig: {
                create: true,
                update: true,
                detail: true,
              },
              baseUrlPath: '/component',
            },
            exact: true,
          },
          {
            path: '/component/detail/:id',
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__component__detail__index" */ '../component/detail/index.tsx'),
                  LoadingComponent: require('/mnt/f/www/basic_framework/go-demo/template/testv3/src/components/PageLoading/index')
                    .default,
                })
              : require('../component/detail/index.tsx').default,
            extendConfig: {
              keyList: [
                {
                  key: 'id',
                  title: 'id',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: true,
                },
                {
                  key: 'display_name',
                  title: '组件名',
                  var_type: 'string',
                  is_show_in_list: true,
                  is_unique_key: false,
                },
                {
                  key: 'package_name',
                  title: 'npm包名',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'dev_list_json',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'description',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'site_url',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
                {
                  key: 'remark',
                  var_type: 'string',
                  is_show_in_list: false,
                  is_unique_key: false,
                },
              ],
              baseApiPath: '/api/component',
              pageConfig: {
                create: true,
                update: true,
                detail: true,
              },
              baseUrlPath: '/component',
            },
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('/mnt/f/www/basic_framework/go-demo/template/testv3/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
        exact: false,
      },
      {
        component: () =>
          React.createElement(
            require('/mnt/f/www/basic_framework/go-demo/template/testv3/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () => import(/* webpackChunkName: "p__404" */ '../404'),
          LoadingComponent: require('/mnt/f/www/basic_framework/go-demo/template/testv3/src/components/PageLoading/index')
            .default,
        })
      : require('../404').default,
    exact: true,
  },
  {
    component: () =>
      React.createElement(
        require('/mnt/f/www/basic_framework/go-demo/template/testv3/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen() {}

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    // dva 中 history.listen 会初始执行一次
    // 这里排除掉 dva 的场景，可以避免 onRouteChange 在启用 dva 后的初始加载时被多执行一次
    const isDva =
      history.listen
        .toString()
        .indexOf('callback(history.location, history.action)') > -1;
    if (!isDva) {
      routeChangeHandler(history.location);
    }
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
