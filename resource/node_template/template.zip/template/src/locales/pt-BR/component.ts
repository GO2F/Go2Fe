export default {
  'component.tagSelect.expand': 'Expandir',
  'component.tagSelect.collapse': 'Diminuir',
  'component.tagSelect.all': 'Todas',
};
